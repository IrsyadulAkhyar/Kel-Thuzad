<!-- FOOTER -->
<footer id="footer" class="section section-black">

<!-- container -->
<div class="container">

    <!-- row -->
    <div class="row">

        <!-- footer widget -->
        <div class="col-md-10 col-sm-10 col-xs-10">

            <div class="footer">

                <h2 class="ftco-heading-2 footer-content footer-header footer-padding">About Auto<span style="color: goldenrod;">Parts</span></h2>
                  <p class="footer-content">Made by our beloved amateur Programmer <a href="#" style="color: goldenrod; text-decoration: none">[Diaz Farindra]</a> in Senior High School, simply program made easy but hard to do it, so yeah this is it my first Application Program.</p>

                <!-- footer social -->
                <ul class="footer-social">

                    <p>Find me on :</p>

                    <li><a href="#" class="footer-content"><i class="fa fa-facebook"></i></a></li>
                    <li><a href="#" class="footer-content"><i class="fa fa-twitter"></i></a></li>
                    <li><a href="#" class="footer-content"><i class="fa fa-instagram"></i></a></li>
                    <li><a href="#" class="footer-content"><i class="fa fa-google-plus"></i></a></li>
                    <li><a href="#" class="footer-content"><i class="fa fa-pinterest"></i></a></li>

                </ul>
                <!-- /footer social -->

            </div>

        </div>
        <!-- /footer widget -->

        <!-- footer info -->
        <div class="col-md-2 col-sm-2 col-xs-2">

            <div class="footer">

                <h3 class="footer-header">Have a Questions?</h3>

                <div class="block-23 mb-3">

                    <ul>
                        <li><a href="#" class="footer-content"><span><span class="fa fa-map-marker"></span> <br> Villa Pertiwi <br> Block I6 no. 10</span></a></li><br>
                        <li><a href="#" class="footer-content"><span><span class="fa fa-phone"></span> <br> +62 878 5523 3702</span></a></li><br>
                        <li><a href="#" class="footer-content"><span><span class="fa fa-mail-forward"></span> <br> farindrad@gmail.com</span></a></li><br>
                    </ul>

                </div>

            </div>

        </div>
        <!-- /footer info -->

    </div>
    <!-- /row -->

    <!-- row -->
    <div class="row">

        <div class="col-md-12 text-center">

            <!-- footer copyright -->
            <div class="footer-copyright">

                Copyright &copy; <script>document.write(new Date().getFullYear());</script> 
                All rights reserved <i class="fa fa-heart" aria-hidden="true"></i> by <a href="#">Diaz Farindra</a>

            </div>
            <!-- /footer copyright -->

        </div>

    </div>
    <!-- /row -->

</div>
<!-- /container -->

</footer>
<!-- /FOOTER -->

<!-- jQuery Plugins -->
<script src="<?= BASEURL; ?>js/jquery.min.js"></script>
<script src="<?= BASEURL; ?>js/bootstrap.min.js"></script>
<script src="<?= BASEURL; ?>js/slick.min.js"></script>
<script src="<?= BASEURL; ?>js/nouislider.min.js"></script>
<script src="<?= BASEURL; ?>js/jquery.zoom.min.js"></script>
<script src="<?= BASEURL; ?>js/main.js"></script>
<script src="<?= BASEURL; ?>js/bootstrap-datepicker.js"></script>

</body>

</html>