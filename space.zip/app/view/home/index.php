
<!-- <ul class="list-group">

	<?php foreach ($data['item'] as $item) : ?>

	<li class="list-group-item"><?= $item['username']; ?></li>

	<?php endforeach; ?>

</ul> -->

<!-- section -->
<div class="section">

	<!-- container -->
	<div class="container">

		<!-- row -->
		<div class="row">

			<!-- banner -->
			<div class="col-md-4 col-sm-6">

				<a class="banner banner-1" href="#">

					<img src="<?= BASEURL; ?>img/asset/post1.jpg" alt="">

					<div class="banner-caption text-center">
						<h2 class="white-color">NEW LOOKSYLE</h2>
					</div>

				</a>

			</div>
			<!-- /banner -->

			<!-- banner -->
			<div class="col-md-4 col-sm-6">

				<a class="banner banner-1" href="#">

					<img src="<?= BASEURL; ?>img/asset/post2.jpg" alt="">

					<div class="banner-caption text-center">
						<h2 class="white-color">INTERIOR COLLECTION</h2>
					</div>

				</a>

			</div>
			<!-- /banner -->

			<!-- banner -->
			<div class="col-md-4 col-md-offset-0 col-sm-6 col-sm-offset-3">

				<a class="banner banner-1" href="#">

					<img src="<?= BASEURL; ?>img/asset/post3.jpg" alt="">

					<div class="banner-caption text-center">
						<h2 class="white-color">TIRES</h2>
					</div>

				</a>

			</div>
			<!-- /banner -->

		</div>
		<!-- /row -->

	</div>
	<!-- /container -->

</div>
<!-- /section -->

<!-- section -->
<div class="section" id="shop">

	<!-- container -->
	<div class="container">

		<!-- row -->
		<div class="row">
			
			<!-- section title -->
			<div class="col-md-12">

				<div class="section-title">

					<h2 class="title">Deals Of The Day</h2>

					<div class="pull-right">
						<div class="product-slick-dots-2 custom-dots"></div>
					</div>

				</div>

			</div>
			<!-- section title -->

			<!-- Product Single -->
			<div class="col-md-3 col-sm-6 col-xs-6">

				<div class="product product-single product-hot">

					<div class="product-thumb">

						<div class="product-label">
							<span class="sale">-20%</span>
						</div>

						<a href="<?= BASEURL; ?>product/detailItem/<?= $item['item_id'] ?>"><button class="main-btn quick-view"><i class="fa fa-search-plus"></i> Product Details</button></a>
						<img src="<?= BASEURL; ?>img/asset/<?= $data['item'][1]['item_photo']; ?>.jpg" alt="">

					</div>

					<div class="product-body">

						<h3 class="product-price">$<?= $data['item'][1]['item_price']; ?>.0<del class="product-old-price">$100.0</del></h3>

						<h2 class="product-name"><a href="#"><?= $data['item'][1]['item_name']; ?></a></h2>

						<div class="product-btns">
							<button class="primary-btn add-to-cart"><i class="fa fa-shopping-cart"></i> Add to Cart</button>
						</div>

					</div>

				</div>

			</div>
			<!-- /Product Single -->

			<!-- Product Slick -->
			<div class="col-md-9 col-sm-6 col-xs-6">

				<div class="row">

					<div id="product-slick-2" class="product-slick">

					<?php foreach ($data['item'] as $item) : ?>
						<!-- Product Single 0-->
						<div class="product product-single">

							<div class="product-thumb">
								<a href="<?= BASEURL; ?>product/detailItem/<?= $item['item_id'] ?>"><button class="main-btn quick-view"><i class="fa fa-search-plus"></i> Product Details</button></a>
								<img src="<?= BASEURL; ?>img/asset/<?= $item['item_photo'] ?>.jpg" alt="">
							</div>

							<div class="product-body">

								<h3 class="product-price">$<?= $item['item_price'] ?>.0</h3>

								<h2 class="product-name"><a href="#"><?= $item['item_name'] ?></a></h2>

						<form action="<?= BASEURL; ?>product/addToChart" method="post">

							<div class="form-group">
								<input type="hidden" class="form-control" id="item_name" name="item_name" value="<?= $item['item_name'] ?>">
							</div>
							<div class="form-group">
								<input type="hidden" class="form-control" id="item_price" name="item_price" value="<?= $item['item_price'] ?>">
							</div>
							<div class="form-group">
								<input type="hidden" class="form-control" id="item_stock" name="item_stock" value="<?= $item['item_stock'] ?>">
							</div>
							<div class="form-group">
								<input type="hidden" class="form-control" id="item_description" name="item_description" value="<?= $item['item_description'] ?>">
							</div>
							<div class="form-group">
								<input type="hidden" class="form-control" id="item_photo" name="item_photo" value="<?= $item['item_photo'] ?>">
							</div>

								<div class="product-btns">
									<button type="submit" class="primary-btn add-to-cart"><i class="fa fa-shopping-cart"></i> Add to Cart</button>
									<a href="<?= BASEURL; ?>product/addToChart/<?= $item['item_id'] ?>"></a>
								</div>

						</form>

							</div>

						</div>
						<!-- /Product Single -->
					<?php endforeach; ?>

					</div>

				</div>

			</div>
			<!-- /Product Slick -->

		</div>
		<!-- /row -->

	</div>
	<!-- /container -->

</div>
<!-- /section -->

<!-- section -->
<div class="section section-grey">

	<!-- container -->
	<div class="container">

		<!-- row -->
		<div class="row">

			<!-- banner -->
			<div class="col-md-8">

				<div class="banner banner-1">

					<img src="<?= BASEURL; ?>img/asset/action-automobile-automotive-1322331.jpg" alt="">

					<div class="banner-caption text-center">
						<h1 class="primary-color">HOT DEAL<br><span class="white-color font-weak">Up to 50% OFF</span></h1>
						<button class="primary-btn">Shop Now</button>
					</div>

				</div>

			</div>
			<!-- /banner -->

			<!-- banner -->
			<div class="col-md-4 col-sm-6">

				<a class="banner banner-1" href="#">

					<img src="<?= BASEURL; ?>img/asset/asphalt-automobile-automotive-1005632.jpg" alt="">

					<div class="banner-caption text-center">
						<h2 class="white-color">BEST PRICE</h2>
					</div>

				</a>

			</div>
			<!-- /banner -->

			<!-- banner -->
			<div class="col-md-4 col-sm-6">

				<a class="banner banner-1" href="#">

					<img src="<?= BASEURL; ?>img/asset/4x4-desert-dust-1149066.jpg" alt="">

					<div class="banner-caption text-center">
						<h2 class="white-color">HIGH QUALITY</h2>
					</div>

				</a>

			</div>
			<!-- /banner -->

		</div>
		<!-- /row -->

	</div>
	<!-- /container -->

</div>
<!-- /section -->

<!-- section -->
<div class="section">

	<!-- container -->
	<div class="container">

		<!-- row -->
		<div class="row">

			<!-- section title -->
			<div class="col-md-12">

				<div class="section-title">
					<h2 class="title">Latest Products</h2>
				</div>

			</div>
			<!-- section title -->
			
			<?php foreach ($data['item'] as $item) : ?>
			<!-- Product Single -->
			<div class="col-md-3 col-sm-6 col-xs-6">

				<div class="product product-single">

					<div class="product-thumb">
							<a href="<?= BASEURL; ?>product/detailItem/<?= $item['item_id'] ?>"><button class="main-btn quick-view"><i class="fa fa-search-plus"></i> Product Details</button></a>
							<img src="<?= BASEURL; ?>img/asset/<?= $item['item_photo'] ?>.jpg" alt="">

						</div>

						<div class="product-body">

							<h3 class="product-price">$<?= $item['item_price'] ?>.0</h3>

							<h2 class="product-name"><a href="#"><?= $item['item_name'] ?></a></h2>

							<form action="<?= BASEURL; ?>product/addToChart" method="post">

							<div class="form-group">
								<input type="hidden" class="form-control" id="item_name" name="item_name" value="<?= $item['item_name'] ?>">
							</div>
							<div class="form-group">
								<input type="hidden" class="form-control" id="item_price" name="item_price" value="<?= $item['item_price'] ?>">
							</div>
							<div class="form-group">
								<input type="hidden" class="form-control" id="item_stock" name="item_stock" value="<?= $item['item_stock'] ?>">
							</div>
							<div class="form-group">
								<input type="hidden" class="form-control" id="item_description" name="item_description" value="<?= $item['item_description'] ?>">
							</div>
							<div class="form-group">
								<input type="hidden" class="form-control" id="item_photo" name="item_photo" value="<?= $item['item_photo'] ?>">
							</div>

								<div class="product-btns">
									<button type="submit" class="primary-btn add-to-cart"><i class="fa fa-shopping-cart"></i> Add to Cart</button>
									<a href="<?= BASEURL; ?>product/addToChart/<?= $item['item_id'] ?>"></a>
								</div>

							</form>

						</div>

					</div>

				</div>

			<?php endforeach; ?>
			<!-- /Product Single -->

		</div>
		<!-- /row -->

	</div>
	<!-- /container -->

</div>
<!-- /section -->
