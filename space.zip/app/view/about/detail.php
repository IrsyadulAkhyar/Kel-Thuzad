
<div class="container mt-5">

    <div class="card" style="width: 18rem;">
        <div class="card-body">
            <h5 class="card-title"><?= $data['page']['username'] ?></h5>
            <h6 class="card-subtitle mb-2 text-muted"><?= $data['page']['email'] ?></h6>
            <h6 class="card-subtitle mb-2 text-muted"><?= $data['page']['phone'] ?></h6>
            <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
            <a href="<?= BASEURL; ?>page" class="card-link">Get Back</a>
        </div>
    </div>

</div>
