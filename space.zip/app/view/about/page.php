
<div class="container mt-3">

    <div class="row">

        <div class="col-lg-6">

            <?php Flasher::flash(); ?>

        </div>

    </div>

    <div class="row mb-3">

        <div class="col-lg-6">

            <!-- Button Triger Add Data -->
            <button type="button" class="btn btn-primary addData" data-toggle="modal" data-target="#formModal">
                Add Data
            </button>

        </div>

    </div>

    <div class="row mb-3">

        <div class="col-lg-6">

            <form action="<?= BASEURL; ?>page/search" method="post">
        
                <div class="input-group">
                    <input type="text" class="form-control" placeholder="Search Data . . ." name="keyword" id="keyword" autocomplete="off">
                    <div class="input-group-append">
                        <button class="btn btn-outline-primary" type="submit" id="search">Search</button>
                    </div>
                </div>

            </form>

        </div>

    </div>

    <div class="row">
    
        <div class="col-lg-6">
        
            <h3>Collage List</h3>

            <ul class="list-group">
                <?php foreach ( $data['page'] as $page ) : ?>

                    <li class="list-group-item">
                    <?= $page['username'] ?>
                    <a class="badge badge-danger float-right" href="<?= BASEURL; ?>Page/delete/<?= $page['id'] ?>" onclick="return confirm('Are You Sure?');">delete</a>
                    <a class="badge badge-warning float-right mr-1 editData" href="<?= BASEURL; ?>Page/edit/<?= $page['id'] ?>" data-toggle="modal" data-target="#formModal" data-id="<?= $page['id']; ?>">Edit</a>
                    <a class="badge badge-primary float-right mr-1" href="<?= BASEURL; ?>Page/detail/<?= $page['id'] ?>">detail</a>
                    </li>

                <?php endforeach; ?>
            </ul>

        </div>

    </div>

</div>



<!-- Launch Menu Add Data -->
<div class="modal fade" id="formModal" tabindex="-1" role="dialog" aria-labelledby="formModal" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">

        <h5 class="modal-title" id="modalTitle">Add Data</h5>

        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>

      </div>
      <div class="modal-body linkEditData">
        
        <form action="<?= BASEURL; ?>Page/add" method="post">

        <input type="hidden" name="id" id="id">

        <div class="form-group">
            <label for="username">Username</label>
            <input type="text" class="form-control" id="username" name="username">
        </div>
        <div class="form-group">
            <label for="email">Email</label>
            <input type="email" class="form-control" id="email" name="email">
        </div>
        <div class="form-group">
            <label for="phone">Phone</label>
            <input type="number" class="form-control" id="phone" name="phone">
        </div>

      </div>

      <div class="modal-footer buttonEdit">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Save</button>

        </form>

      </div>
    </div>
  </div>
</div>
