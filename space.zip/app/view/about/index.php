<div class="container">

    <div class="jumbotron">
    
    <h1>About / Index Connect</h1>

    <p>Hi, My name is <?= $data['name'] ?> and i'am a <?= $data['job'] ?></p>

    </div>

</div>

    
    
    