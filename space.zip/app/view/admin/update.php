
<div class="section">

    <div class="container">

        <div class="row">

            <div class="col-lg-12">

            <form action="<?= BASEURL; ?>yazbros1902/editData" method="post">

                <input type="hidden" name="item_id" id="item_id" value="<?= $data['item']['item_id'] ?>">

                <div class="form-group">
                    <label for="item_name">ITEM NAME</label>
                    <input type="text" class="form-control" id="item_name" name="item_name" value="<?= $data['item']['item_name'] ?>">
                </div>

                <div class="form-group">
                    <label for="item_price">ITEM PRICE</label>
                    <input type="text" class="form-control" id="item_price" name="item_price" value="<?= $data['item']['item_price'] ?>">
                </div>

                <div class="form-group">
                    <label for="item_stock">ITEM STOCK</label>
                    <input type="text" class="form-control" id="item_stock" name="item_stock" value="<?= $data['item']['item_stock'] ?>">
                </div>

                <div class="form-group">
                    <label for="item_description">ITEM DESCRIPTION</label>
                    <input type="text" class="form-control" id="item_description" name="item_description" value="<?= $data['item']['item_description'] ?>">
                </div>

                <div class="form-group">
                    <label for="item_photo">ITEM PHOTO</label>
                    <input type="text" class="form-control" id="item_photo" name="item_photo" value="<?= $data['item']['item_photo'] ?>">
                </div>

                <button type="submit" class="btn btn-primary">edit Item</button>

            </form>

            </div>

        </div>

    </div>

</div>