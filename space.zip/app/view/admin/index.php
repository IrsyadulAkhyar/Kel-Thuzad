
<!-- Make a Blank Page -->
<!-- <div class="section">
    <div class="container">
        <div class="row">
        </div>
    </div>
</div> -->


<div class="section">

    <div class="container">

        <div class="row">

            <div class="col-lg-6">
                
                <div class="row">

                <?php foreach ( $data['item'] as $item ) : ?>

                    <div class="col-sm-6">

                        <div class="card">

                        <img class="card-img-top img-thumbnail" src="<?= BASEURL; ?>img/asset/<?= $item['item_photo'] ?>.jpg" alt="Card image cap">

                        <div class="card-body">
                            <h5 class="card-title"><?= $item['item_name'] ?></h5>
                            <p class="card-text">Price : $<?= $item['item_price'] ?>.0</p>
                            <p class="card-text">Stock Left : <?= $item['item_stock'] ?> item</p>
                            <p class="card-text">Description : <?= $item['item_description'] ?></p>
                            <a href="<?= BASEURL; ?>yazbros1902/update/<?= $item['item_id'] ?>" class="btn btn-primary">edit</a>
                            <a href="<?= BASEURL; ?>yazbros1902/deleteData/<?= $item['item_id'] ?>" class="btn btn-danger" onclick="return confirm('Are You Sure?')">Delete</a>
                        </div>

                        </div>

                    </div>

                <?php endforeach; ?>

                </div>
                
            </div>

            <div class="col-lg-6">

                <form action="<?= BASEURL; ?>yazbros1902/addData" method="post">

                    <input type="hidden" name="item_id" id="item_id">

                    <div class="form-group">
                        <label for="item_name">ITEM NAME</label>
                        <input type="text" class="form-control" id="item_name" name="item_name">
                    </div>

                    <div class="form-group">
                        <label for="item_price">ITEM PRICE</label>
                        <input type="text" class="form-control" id="item_price" name="item_price">
                    </div>

                    <div class="form-group">
                        <label for="item_stock">ITEM STOCK</label>
                        <input type="text" class="form-control" id="item_stock" name="item_stock">
                    </div>

                    <div class="form-group">
                        <label for="item_description">ITEM DESCRIPTION</label>
                        <input type="text" class="form-control" id="item_description" name="item_description">
                    </div>

                    <div class="form-group">
                        <label for="item_photo">ITEM PHOTO</label>
                        <input type="text" class="form-control" id="item_photo" name="item_photo">
                    </div>

                    <button type="submit" class="btn btn-warning">Add Item</button>

                </form>

            </div>
            
        </div>
        
    </div>

</div>


















<!-- Launch Menu Add Data
<div class="modal fade" id="formModal" tabindex="-1" role="dialog" aria-labelledby="formModal" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">

        <h5 class="modal-title" id="modalTitle">Add Data</h5>

        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>

      </div>
      <div class="modal-body linkEditData">
        
        <form action="<?= BASEURL; ?>yazbros1902/editData" method="post">

        <input type="hidden" name="item_id" id="item_id">

        <div class="form-group">
            <label for="item_name">ITEM NAME</label>
            <input type="text" class="form-control" id="item_name" name="item_name">
        </div>

        <div class="form-group">
            <label for="item_price">ITEM PRICE</label>
            <input type="text" class="form-control" id="item_price" name="item_price">
        </div>

        <div class="form-group">
            <label for="item_stock">ITEM STOCK</label>
            <input type="text" class="form-control" id="item_stock" name="item_stock">
        </div>

        <div class="form-group">
            <label for="item_description">ITEM DESCRIPTION</label>
            <input type="text" class="form-control" id="item_description" name="item_description">
        </div>

        <div class="form-group">
            <label for="item_photo">ITEM PHOTO</label>
            <input type="text" class="form-control" id="item_photo" name="item_photo">
        </div>

      </div>

      <div class="modal-footer buttonEdit">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Save</button>

        </form>

      </div>
    </div>
  </div>
</div> -->
