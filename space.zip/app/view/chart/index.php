
<div class="section">

    <div class="container">

        <div class="row">

            <div class="col-md-12">

            <div class="order-summary clearfix">

                <div class="section-title">
                    <h3 class="title">Order Review</h3>
                </div>

                <table class="shopping-cart-table table">

                    <thead>

                        <tr>
                            <th>Product</th>
                            <th>Name Product</th>
                            <th class="text-center">Price</th>
                            <th class="text-right">delete</th>
                        </tr>

                    </thead>

                    <tbody>

                        <?php foreach ($data['chart'] as $chart) : ?>

                        <tr>
                            
                            <td class="thumb">
                                <img src="<?= BASEURL; ?>img/asset/<?= $chart['item_photo'] ?>.jpg">
                            </td>

                            <td class="details">
                                <a href="#"><?= $chart['item_name'] ?></a>
                            </td>

                            <td class="price text-center"><strong>$<?= $chart['item_price'] ?>.0</strong></td>
                            <td class="text-right"><a href="<?= BASEURL; ?>chart/deleteChart/<?= $chart['chart_id'] ?>"><i class="fa fa-close"></i></a></td>

                        </tr>

                        <?php endforeach; ?>

                    </tbody>

                    <tfoot>

                        <tr>										
                            <th>SUBTOTAL</th>
                            <th colspan="2" class="sub-total">$00.0</th>
                        </tr>

                        <tr>										
                            <th>SHIPING</th>
                            <td colspan="2">Regular Shipping</td>
                        </tr>

                        <tr>										
                            <th>TOTAL</th>
                            <th colspan="2" class="total">$00.0</th>
                        </tr>

                    </tfoot>

                </table>

                <div class="pull-left">
                    <a href="<?= BASEURL; ?>checkout"><button class="primary-btn">Checkout</button></a>
                </div>

            </div>

            </div>

        </div>

    </div>

</div>