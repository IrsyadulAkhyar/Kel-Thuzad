<!-- section -->
<div class="section">

<!-- container -->
<div class="container">

    <!-- row -->
    <div class="row">

        <!--  Product Details -->
        <div class="product product-details clearfix">

            <div class="col-md-6">
                <div id="product-main-view">
                    <div class="product-view">
                        <img src="<?= BASEURL; ?>img/asset/<?= $data['product']['item_photo'] ?>.jpg" alt="">
                    </div>
                </div>	
            </div>
            
            <div class="col-md-6">

                <div class="product-body">
                    
                    <h2 class="product-name"><?= $data['product']['item_name'] ?></h2>
                    <h3 class="product-price">$<?= $data['product']['item_price'] ?>.0</h3>
                    <p><strong>Availability:</strong> In Stock = <?= $data['product']['item_stock'] ?></p>
                    <p><?= $data['product']['item_description'] ?></p>

                    <div class="product-btns">

                        <div class="qty-input">
                            <span class="text-uppercase">QTY: </span>
                            <input class="input" type="number">
                        </div>

                        <form action="<?= BASEURL; ?>product/addToChart" method="post">

							<div class="form-group">
								<input type="hidden" class="form-control" id="item_name" name="item_name" value="<?= $data['product']['item_name'] ?>">
							</div>
							<div class="form-group">
								<input type="hidden" class="form-control" id="item_price" name="item_price" value="<?= $data['product']['item_price'] ?>">
							</div>
							<div class="form-group">
								<input type="hidden" class="form-control" id="item_stock" name="item_stock" value="<?= $data['product']['item_stock'] ?>">
							</div>
							<div class="form-group">
								<input type="hidden" class="form-control" id="item_description" name="item_description" value="<?= $data['product']['item_description'] ?>">
							</div>
							<div class="form-group">
								<input type="hidden" class="form-control" id="item_photo" name="item_photo" value="<?= $data['product']['item_photo'] ?>">
							</div>

								<div class="product-btns">
									<button type="submit" class="primary-btn add-to-cart"><i class="fa fa-shopping-cart"></i> Add to Cart</button>
									<a href="<?= BASEURL; ?>product/addToChart/<?= $data['product']['item_id'] ?>"></a>
								</div>

							</form>

                    </div>

                </div>

            </div>

        </div>
        <!-- /Product Details -->

    </div>
    <!-- /row -->

</div>
<!-- /container -->

</div>
<!-- /section -->