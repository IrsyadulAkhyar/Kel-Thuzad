<?php

class Page extends Controller {

    public function index()
    {

        $data['title'] = 'About/page';
        $data['page'] = $this->model('Page_model')->getAllData();

        $this->view('bracket/header', $data);
        $this->view('about/page', $data);
        $this->view('bracket/footer');

    }

    public function detail($id)
    {

        $data['title'] = 'About/page Detail';
        $data['page'] = $this->model('Page_model')->getDataById($id);

        $this->view('bracket/header', $data);
        $this->view('about/detail', $data);
        $this->view('bracket/footer');

    }

    public function add()
    {

        if ( $this->model('page_model')->addPageData($_POST) > 0 ) {

            flasher::setFlash(' Successfully', 'Added', 'success');

            header('Location: ' . BASEURL . '/page');
            exit;

        } else {

            flasher::setFlash(' unSuccessfully', 'Added', 'danger');

        }

    }

    public function delete($id)
    {

        if ( $this->model('page_model')->deletePageData($id) > 0 ) {

            flasher::setFlash(' Successfully', 'delete', 'success');

            header('Location: ' . BASEURL . '/page');
            exit;

        } else {

            flasher::setFlash(' unSuccessfully', 'delete', 'danger');

        }

    }

    public function getEdit()
    {
    
        echo json_encode ( $this->model('page_model')->getDataById($_POST['id']) );

    }

    public function edit()
    {

        if ( $this->model('page_model')->editPageData($_POST) > 0 ) {

            flasher::setFlash(' Successfully', 'Edit', 'success');

            header('Location: ' . BASEURL . '/page');
            exit;

        } else {

            flasher::setFlash(' unSuccessfully', 'Edit', 'danger');
            
            header('Location: ' . BASEURL . '/page');
            exit;

        }

    }

    public function search()
    {
    
        $data['title'] = 'About/page';
        $data['page'] = $this->model('Page_model')->searchData();

        $this->view('bracket/header', $data);
        $this->view('about/page', $data);
        $this->view('bracket/footer');

    }
    
}
