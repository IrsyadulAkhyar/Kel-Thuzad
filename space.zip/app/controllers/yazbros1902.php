<?php 

class yazbros1902 extends Controller {

    public function index()
    {

        $data['title'] = 'ADMIN -Diaz Farindra';
        $data['chart'] = $this->model('admin_model')->getChartData();
        $data['item'] = $this->model('Admin_model')->getAllData();

        $this->view('bracket/header', $data);
        $this->view('admin/index', $data);
        $this->view('bracket/footer');

    }

    public function update($item_id)
    {

        $data['title'] = 'ADMIN -Diaz Farindra';
        $data['item'] = $this->model('Admin_model')->getDataById($item_id);

        $this->view('bracket/header', $data);
        $this->view('admin/update', $data);
        $this->view('bracket/footer');

    }

    public function addData()
    {

        if ( $this->model('admin_model')->addItemData($_POST) > 0 ) {

            flasher::setFlash('Successfully', 'Added', 'success');

            header ('location: ' . BASEURL . 'yazbros1902');
            exit;

        } else {

            flasher::setFlash('UnSuccessfuly', 'Added', 'danger');

        }

    }

    public function deleteData($item_id)
    {

        if ( $this->model('admin_model')->deleteItemData($item_id) > 0 ) {

            flasher::setFlash(' Successfully', 'delete', 'success');

            header('Location: ' . BASEURL . 'yazbros1902');
            exit;

        } else {

            flasher::setFlash(' unSuccessfully', 'delete', 'danger');

        }

    }

    public function editData()
    {

        
        if ( $this->model('admin_model')->editItemData($_POST) > 0 ) {
            
            flasher::setFlash(' Successfully', 'Edit', 'success');
            
            header('Location: ' . BASEURL . 'yazbros1902');
            exit;
            
        } else {
            
            flasher::setFlash(' unSuccessfully', 'Edit', 'danger');
            
        }

    }

}
