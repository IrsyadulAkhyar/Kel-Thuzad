<?php 

    class Checkout extends Controller {

        public function index()
        {

            $data['title'] = 'Checkout';
            $data['item'] = $this->model('checkout_model')->getItemData();
            $data['chart'] = $this->model('checkout_model')->getChartData();

            $this->view('bracket/header', $data);
            $this->view('checkout/index', $data);
            $this->view('bracket/footer');

        }

        public function deleteChart($chart_id)
        {

            $this->model('checkout_model')->deleteChartData($chart_id);

            header ('location: ' . BASEURL . 'checkout');
            exit;
            
        }

}
