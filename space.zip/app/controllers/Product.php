<?php 

class Product extends Controller {

    public function index()
    {

        $data['title'] = 'Detail Product -Diaz Farindra';
        $data['item'] = $this->model('Admin_model')->getAllData();
        $data['product'] = $this->model('product_model')->getAllItem();

        $this->view('bracket/header', $data);
        $this->view('product/index', $data);
        $this->view('bracket/footer');

    }

    public function detailItem($item_id)
    {

        $data['title'] = 'Detail Product -Diaz Farindra';
        $data['item'] = $this->model('Admin_model')->getAllData();
        $data['product'] = $this->model('product_model')->getDataById($item_id);

        $this->view('bracket/header', $data);
        $this->view('product/index', $data);
        $this->view('bracket/footer');

    }

    public function addToChart()
    {

        $this->model('product_model')->addChartData($_POST);

        header ('location:' . BASEURL);
        exit;

    }

}
