<?php

class Home extends Controller {

    public function index() 
    {

        // echo 'home/index connect';

        $data['title'] = 'Home';
        $data['item'] = $this->model("Home_model")->getItemData();
        $data['chart'] = $this->model('home_model')->getChartData();

        $this->view('bracket/header', $data);
        $this->view('home/index', $data);
        $this->view('bracket/footer');

    }

    public function deleteChart($chart_id)
    {

        $this->model('home_model')->deleteChartData($chart_id);

        header ('location: ' . BASEURL);
        exit;
        
    }

}
