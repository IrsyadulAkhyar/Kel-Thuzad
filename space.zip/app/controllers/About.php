<?php

class About extends Controller {

    public function index($name = "diaz", $job = "programmer")
    {

        // echo "Hello, my name is $name & i'am a $job";
        
        
        $data['name'] = $name;
        $data['job'] = $job;
        $data['title'] = 'About/index';

        $this->view('bracket/header', $data);
        $this->view('about/index', $data);
        $this->view('bracket/footer');

    }

}
