<?php 

class Chart extends Controller {

    public function index()
    {

        $data['title'] = 'CHART';
        $data['chart'] = $this->model('chart_model')->getChartData();

        $this->view('bracket/header', $data);
        $this->view('chart/index', $data);
        $this->view('bracket/footer');
        
    }

    public function chartData()
    {

        $this->model('chart_model')->getChartData();

    }

    public function deleteChart($chart_id)
    {

        $this->model('chart_model')->deleteChartData($chart_id);

        header ( 'location: ' . BASEURL . ' chart' );
        exit;

    }



}
