<?php 

 class Checkout_model {

    private $table = 'item';
    private $chart = 'chart';
    private $db;

    public function __construct()
    {
        
        $this->db = new Database;

    }

    public function getItemData()
    {

        $this->db->query('SELECT * FROM ' . $this->table);
        return $this->db->resultSet();

    }

    public function getChartData()
    {

        $this->db->query('SELECT * FROM ' . $this->chart);
        return $this->db->resultSet();

    }

    public function deleteChartData($chart_id)
    {

        $query = 'DELETE FROM chart WHERE chart_id = :chart_id';
        
        $this->db->query($query);
        $this->db->bind('chart_id', $chart_id);

        $this->db->execute();
        return $this->db->rowCount();

    }



 }
