<?php 

class Chart_model {

    private $chart = 'chart';
    private $db;

    public function __construct()
    {
        
        $this->db = new Database;

    }

    public function getChartData()
    {

        $this->db->query('SELECT * FROM ' . $this->chart);
        return $this->db->resultSet();

    }

    public function getDataById($chart_id)
    {

        $this->db->query('SELECT * FROM ' . $this->chart . ' WHERE chart_id = :chart_id');
        $this->db->bind('chart_id', $chart_id);
        return $this->db->single();

    }

    public function deleteChartData($chart_id)
    {

        $query = 'DELETE FROM ' . $this->chart . ' WHERE chart_id = :chart_id';
        
        $this->db->query($query);
        $this->db->bind('chart_id', $chart_id);

        $this->db->execute();
        return $this->db->rowCount();

    }



}
