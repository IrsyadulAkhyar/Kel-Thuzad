<?php 

class Admin_model {

    private $table = 'item';
    private $chart = 'chart';
    private $db;

    public function __construct()
    {
        
        $this->db = new Database;

    }

    public function getAllData()
    {

        $this->db->query('SELECT * FROM ' . $this->table);
        return $this->db->resultSet();

    }

    public function getChartData()
    {

        $this->db->query('SELECT * FROM ' . $this->chart);        

    }

    public function getDataById($item_id)
    {

        $this->db->query('SELECT * FROM ' . $this->table . ' WHERE item_id = :item_id');
        $this->db->bind('item_id', $item_id);
        return $this->db->single();

    }

    public function addItemData($data)
    {

        $query = "INSERT INTO " . $this->table . " 
                    VALUES 
                ('', :item_name, :item_price, :item_stock, :item_description, :item_photo)";

        $this->db->query($query);
        $this->db->bind('item_name', $data['item_name']);
        $this->db->bind('item_price', $data['item_price']);
        $this->db->bind('item_stock', $data['item_stock']);
        $this->db->bind('item_description', $data['item_description']);
        $this->db->bind('item_photo', $data['item_photo']);

        $this->db->execute();
        return $this->db->rowCount();

    }

    public function deleteItemData($id)
    {

        $query = "DELETE FROM item WHERE item_id = :item_id";
        $this->db->query($query);
        $this->db->bind('item_id', $id);

        $this->db->execute(); 
        return $this->db->rowCount();

    }

    public function editItemData($data)
    {

        $query = "UPDATE item SET
                    item_name = :item_name,
                    item_price = :item_price,
                    item_stock = :item_stock,
                    item_description = :item_description,
                    item_photo = :item_photo
                WHERE item_id = :item_id";

        $this->db->query($query);
        $this->db->bind('item_name', $data['item_name']);
        $this->db->bind('item_price', $data['item_price']);
        $this->db->bind('item_stock', $data['item_stock']);
        $this->db->bind('item_description', $data['item_description']);
        $this->db->bind('item_photo', $data['item_photo']);
        $this->db->bind('item_id', $data['item_id']);

        $this->db->execute();

        return $this->db->rowCount();

    }

}
