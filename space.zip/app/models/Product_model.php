<?php 

class Product_model {

    private $table = 'item';
    private $chart = 'chart';
    private $db;

    public function __construct()
    {
        
        $this->db = new Database;
        
    }

    public function getAllItem()
    {

        $this->db->query('SELECT * FROM ' . $this->table);
        return $this->db->resultSet();

    }

    public function getAllChart()
    {

        $this->db->query('SELECT * FROM ' . $this->chart);
        return $this->db->resultSet();

    }

    public function getDataById($item_id)
    {

        $this->db->query('SELECT * FROM ' . $this->table . ' WHERE item_id = :item_id');
        $this->db->bind('item_id', $item_id);
        return $this->db->single();

    }

    public function getChartId($chart_id)
    {

        $this->db->query('SELECT * FROM ' . $this->chart . ' WHERE chart_id = :chart_id');
        $this->db->bind('chart_id', $chart_id);
        return $this->db->single();

    }

    public function addChartData($data)
    {

        $query = "INSERT INTO chart
                    VALUES
                    ('', :item_name, :item_price, :item_stock, :item_description, :item_photo)";

        $this->db->query($query);
        $this->db->bind('item_name', $data['item_name']);
        $this->db->bind('item_price', $data['item_price']);
        $this->db->bind('item_stock', $data['item_stock']);
        $this->db->bind('item_description', $data['item_description']);
        $this->db->bind('item_photo', $data['item_photo']);

        $this->db->execute();
        return $this->db->rowCount();

    }

}
