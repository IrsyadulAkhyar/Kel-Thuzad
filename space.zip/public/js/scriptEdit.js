$(function() {

    $('.addData').on('click', function() {

        $('#modalTitle').html('Add Data');
        $('.buttonEdit button[type=submit]').html('Add Data');

    });

    $('.editData').on('click', function() {
        
        $('#modalTitle').html('Edit Data');
        $('.buttonEdit button[type=submit]').html('Edit Data');
        $('.linkEditData form').attr('action', 'http://localhost/LearnPHP/SPACE/public/page/edit');

        const id = $(this).data('id');

        $.ajax({
            url: 'http://localhost/LearnPHP/SPACE/public/page/getEdit',
            data: {id : id}, // id sebelah kiri untuk nama data yg di kirimkan, yg kanan adalah isi datanya  
            method: 'post',
            dataType: 'json',
            success: function(data) {
                $('#username').val(data.username);
                $('#email').val(data.email);
                $('#phone').val(data.phone);
                $('#id').val(data.id);
            }
        });

    });

});