$(function() {

    $('.addData').on('click', function() {

        $('#modalTitle').html('Add Data');
        $('.buttonEdit button[type=submit]').html('Add Data');

    });

    $('.editData').on('click', function() {
        
        $('#modalTitle').html('Edit Data');
        $('.buttonEdit button[type=submit]').html('Edit Data');
        $('.linkEditData form').attr('action', 'http://localhost/LearnPHP/SPACE/public/yazbros1902/editData');

        const id = $(this).data('id');

        $.ajax({
            url: 'http://localhost/LearnPHP/SPACE/public/yazbros1902/editData',
            data: {item_id : item_id}, // id sebelah kiri untuk nama data yg di kirimkan, yg kanan adalah isi datanya  
            method: 'post',
            dataType: 'json',
            success: function(data) {
                $('#item_name').val(data.item_name);
                $('#item_price').val(data.item_price);
                $('#item_stock').val(data.item_stock);
                $('#item_description').val(data.item_description);
                $('#item_photo').val(data.item_photo);
                $('#item_id').val(data.item_id);
            }
        });

    });

});